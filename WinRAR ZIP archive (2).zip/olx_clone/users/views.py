from django.shortcuts import render, redirect
from django.contrib.auth import logout
from .forms import RegisterForm


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, 'users/register.html', {
        'form': form
    })


def logout_view(request):
    logout(request)
    return redirect('/')